#include <bits/stdc++.h>
using namespace std;
 
struct info
 {
    long long int h,r,t,wood;
 };
 
bool acompare(info lhs, info rhs)
{ 
    if(lhs.t==rhs.t) 
    { 
        return lhs.r<rhs.r;
    }
        else return lhs.t < rhs.t;
}
 
int main()
{
  long long int n,w,l,totime;
  cin>>n>>w>>l;
  info tree[100001];
  for(int i=0;i<n;i++)
     {
         cin>>tree[i].h>>tree[i].r;
         if(tree[i].h<l)
         tree[i].t=ceil(double(l-tree[i].h)/tree[i].r);
         else
         tree[i].t=0;
     }
  sort(tree,tree+n,acompare);
  for(int i=1;i<n;i++)
  {
  tree[i].h+=tree[i-1].h;
  tree[i].r+=tree[i-1].r;
  }
  for(int i=0;i<n;i++)
  tree[i].wood=(tree[i].r*tree[i].t)+tree[i].h;
//for(int i=0;i<n;i++)
//cout<<tree[i].h<<" "<<tree[i].r<<" "<<tree[i].t<<" "<<tree[i].wood<<"\n";
  for(int i=0;i<n;i++)
  {
  if(w<tree[i].wood)
        {
            if(i!=0)
            {
            if((w-tree[i-1].h)%tree[i-1].r==0)
            totime=((w-tree[i-1].h)/tree[i-1].r);
            else
            totime=((w-tree[i-1].h)/tree[i-1].r)+1;
            }
            if(i==0)
                 cout<<tree[i].t;
            else if(totime>=tree[i].t)
            cout<<tree[i].t;
            else
            cout<<totime;
            return 0;
        }
  }
  if((w-tree[n-1].h)%tree[n-1].r==0)
  cout<<((w-tree[n-1].h)/tree[n-1].r);
  else
  cout<<((w-tree[n-1].h)/tree[n-1].r)+1;
  return 0;
} 