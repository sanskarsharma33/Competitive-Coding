#if __has_include("debug.h")
    #include "debug.h"
#else
    #include<bits/stdc++.h>
    using namespace std;
#endif

#ifndef DHRUV_GHEEWALA
    #define p(str) 42
    #define o(str) 108
    #define fundri 137
    #define d(...) 1729
#endif

typedef unsigned int ui;
typedef long long int ll;
typedef pair<int,int> pii;
typedef vector<int> vi;

#define fast ios_base::sync_with_stdio(0)
#define test int __T__=0;cin>>__T__;while(__T__--)

#define nl cout<<'\n'
#define pb push_back
#define pop pop_back
#define all(s) s.begin(),s.end()
#define ff first
#define ss second
template<typename T,typename U>inline bool exist(T cont,U val){return cont.find(val)!=cont.end();}

#define rep(i,n) for(int i=0;i<(n);i++)
#define rrep(i,n) for(int i=(n)-1;i>=0;i--)
#define loop(i,l,r) for(int i=l;i<=r;i++)
#define rloop(i,r,l) for(int i=r;i>=l;i--)

template<typename T>bool isPrime(T n){for(T i=2;i*i<=n;i++)if(n%i==0)return 0;return 1;}
template<typename TAIL>inline void inp(TAIL& T){cin>>T;}
template<typename HEAD,typename... TAIL>inline void inp(HEAD &H,TAIL&... T){cin>>H;inp(T...);}
template<typename T>inline bool in_range(T a,T l,T r){return (a>=l&&a<=r);}
template<typename T,typename U>inline istream& operator >>(istream& in,pair<T,U> &a){in>>a.ff>>a.ss;return in;}
template<typename T>inline istream& operator >>(istream& in,vector<T> &a){for(auto &x : a)in>>x;return in;}

ll MOD=1E9+7;
const double PI=2*acos(0.0);
vi INV_EUCLID((int)1e6+1728,0);

inline ll mul(ll a,ll b,ll mod=MOD){return ((a%mod)*(b%mod))%mod;}
inline ll sum(ll a,ll b,ll mod=MOD){return ((a%mod)+(b%mod))%mod;}
ll power(ll a,ll n,ll mod=LLONG_MAX){ll ans=1;while(n){if(n&1)ans=mul(ans,a,mod);a=mul(a,a,mod);n>>=1;}return ans;}

inline ll mmi_euclid(ll b,ll mod){if(INV_EUCLID[1])return INV_EUCLID[b];INV_EUCLID[1]=1;mod=min(mod-1,(ll)1e6+1727);
loop(i,2,mod)INV_EUCLID[i]=(mod-(mod/i)*INV_EUCLID[mod%i]%mod)%mod;return INV_EUCLID[b];}
inline ll fmodinv(ll a,ll mod){return power(a,mod-2,mod);}
inline ll mdiv(ll a,ll b,ll mod=MOD,bool flag=1){if(flag)return mul(a,fmodinv(b,mod),mod);
else return mul(a,mmi_euclid(b,mod),mod);}

inline ll gcd(ll a,ll b){return __gcd(a,b);}
inline ll lcm(ll a,ll b,ll mod=MOD){return mdiv(mul(a,b,mod),gcd(a,b),mod);}
inline long double log(ll num,ll base=10){return log(num)/log(base);}
#define setprec(a) cout<<fixed<<setprecision(a)

inline ll pow2(int n){return (1LL<<n);}
inline int digits(ll x){return (floor(log10(x))+1);}
inline bool isPowerOfTwo(ll x){return (x&&(!(x&(x-1))));}
ll nCr(int n, int r,ll mod){long long p=1,k=1;if(n-r<r)r=n-r;if(r){while(r){
p=mul(p,n);k=mul(k,r);long long m=gcd(p,k);p/=m;k/=m;n--;r--;}}else p=1;return p;}


int main()
{
    std::chrono::time_point<std::chrono::high_resolution_clock> start_time, end_time;
    start_time = std::chrono::high_resolution_clock::now();

    #ifdef DHRUV_GHEEWALA
        // freopen("INPUT.txt","r",stdin);
        // freopen("OUTPUT.txt","w",stdout);
        freopen("DEBUG.txt","w",stderr);
    #endif
    
    fast;
    int n,m,p;
    inp(n,m,p);
    vi a(n),b(m);
    inp(a,b);

    int ln,lm;
    rep(i,n)
    {
        if(gcd(p,a[i])==1)
        {
            ln=i;
            break;
        }
    }
    rep(i,m)
    {
        if(gcd(p,b[i])==1)
        {
            lm=i;
            break;
        }
    }

    cout<<ln+lm,nl;

    end_time = std::chrono::high_resolution_clock::now();
    ll elapsed_time = std::chrono::duration_cast<std::chrono::milliseconds>(end_time-start_time).count();
    o("\n\n======\n");
    o("Elapsed Time: "<<elapsed_time<<" ms\n");

    return 0;
}