//Problem Description
#include<bits/stdc++.h>
using namespace std;

#ifndef DHRUV_GHEEWALA
    #define p(str) 42
    #define o(str) 108
    #define fundri 137
    #define d(...) 1729
#endif

typedef unsigned int ui;
typedef long long int ll;
typedef pair<int,int> pii;
typedef vector<int> vi;

#define fast ios_base::sync_with_stdio(0)
#define test int t=0;cin>>t;while(t--)

#define nl cout<<'\n'
#define pb push_back
#define pop pop_back
#define all(s) s.begin(),s.end()
#define ff first
#define ss second
template<typename T,typename U>inline bool exist(T cont,U val){return cont.find(val)!=cont.end();}

#define rep(i,n) for(int i=0;i<(n);i++)
#define rrep(i,n) for(int i=(n)-1;i>=0;i--)
#define loop(i,l,r) for(int i=l;i<=r;i++)
#define rloop(i,r,l) for(int i=r;i>=l;i--)

template<typename T>bool isPrime(T n){for(T i=2;i*i<=n;i++)if(n%i==0)return 0;return 1;}
template<typename TAIL>inline void inp(TAIL& T){cin>>T;}
template<typename HEAD,typename... TAIL>inline void inp(HEAD &H,TAIL&... T){cin>>H;inp(T...);}
template<typename T>inline bool in_range(T a,T l,T r){return (a>=l&&a<=r);}
template<typename T,typename U>inline istream& operator >>(istream& in,pair<T,U> &a){in>>a.ff>>a.ss;return in;}
template<typename T>inline istream& operator >>(istream& in,vector<T> &a){for(auto &x : a)in>>x;return in;}

ll seed;
mt19937 rng(seed=chrono::steady_clock::now().time_since_epoch().count());
inline int rrand(int l=0,int r=INT_MAX){return uniform_int_distribution<int>(l,r)(rng);}
vector<char> vowels={'a','e','i','o','u'};

template<typename HEAD>void print(HEAD h){cout<<h,nl;}
template<typename HEAD,typename... TAIL>void print(HEAD h,TAIL... t){cout<<h<<" ";print(t...);}

int main()
{
    
    return 0;
}