p is prime : 
	phi(p)=p-1
k>=1 : 
	phi(power(p,k))=power(p,k)-power(p,k-1)
a and b are coprime : 
	phi(a*b)=phi(a)*phi(b)