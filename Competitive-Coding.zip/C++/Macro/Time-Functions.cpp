using namespace std::chrono;

#define UNTIL(t) while(clock()<CLOCKS_PER_SEC*(t))

std::chrono::time_point<std::chrono::high_resolution_clock> start, end;
start = std::chrono::high_resolution_clock::now();
// Code goes here
end = std::chrono::high_resolution_clock::now();
ll elapsed_time = std::chrono::duration_cast<std::chrono::milliseconds>(end-start).count();
cerr<<"Elapsed Time: "<<elapsed_time<<"ms\n";