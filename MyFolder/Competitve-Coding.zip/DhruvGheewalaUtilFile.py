path = 'D:\\Dhruv\\Codes\\C++\\'
elemenator = '$###%###%#############%###%###$'

def holdScreen():
	holdingScreen = input()