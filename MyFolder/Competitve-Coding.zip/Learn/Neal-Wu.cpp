// Profile : https://codeforces.com/profile/neal

// ll floor_div(ll a,ll b){return a/b-((a^b)<0&&a%b!=0);}
// ll ceil_div(ll a,ll b){return a/b+((a^b)>0&&a%b!=0);}

/***********************************
const bool CHECK_OVERFLOW64 = false;
 
struct point {
    long long x, y;
    int index;
 
    point() : x(0), y(0) {}
 
    point(long long _x, long long _y) : x(_x), y(_y) {}
 
    point& operator+=(const point &other) { x += other.x; y += other.y; return *this; }
    point& operator-=(const point &other) { x -= other.x; y -= other.y; return *this; }
    point& operator*=(long long mult) { x *= mult; y *= mult; return *this; }
 
    point operator+(const point &other) const { return point(*this) += other; }
    point operator-(const point &other) const { return point(*this) -= other; }
    point operator*(long long mult) const { return point(*this) *= mult; }
 
    bool operator==(const point &other) const { return x == other.x && y == other.y; }
    bool operator!=(const point &other) const { return !(*this == other); }
 
    point operator-() const { return point(-x, -y); }
    point rotate90() const { return point(-y, x); }
 
    long long norm() const {
        return (long long) x * x + (long long) y * y;
    }
 
    long double dist() const {
        return sqrt((long double) norm());
    }
 
    bool top_half() const {
        return y > 0 || (y == 0 && x > 0);
    }
 
    friend ostream& operator<<(ostream &stream, const point &p) {
        return stream << '(' << p.x << ", " << p.y << ')';
    }
};
 
long long cross(const point &a, const point &b) {
    return (long long) a.x * b.y - (long long) b.x * a.y;
}
 
long long dot(const point &a, const point &b) {
    return (long long) a.x * b.x + (long long) a.y * b.y;
}
 
int cross_sign(const point &a, const point &b) {
    if (CHECK_OVERFLOW64) {
        long double double_value = (long double) a.x * b.y - (long double) b.x * a.y;
 
        if (abs(double_value) > 1e18)
            return double_value > 0 ? +1 : -1;
    }
 
    uint64_t uint64_value = (uint64_t) a.x * b.y - (uint64_t) b.x * a.y;
 
    if (uint64_value == 0)
        return 0;
 
    return uint64_value >> 63 ? -1 : +1;
}
 
bool left_turn_strict(const point &a, const point &b, const point &c) {
    return cross_sign(b - a, c - a) > 0;
}
 
bool left_turn_lenient(const point &a, const point &b, const point &c) {
    return cross_sign(b - a, c - a) >= 0;
}
 
bool collinear(const point &a, const point &b, const point &c) {
    return cross_sign(b - a, c - a) == 0;
}
 
// Returns twice the signed area formed by three points in a triangle. Positive when a -> b -> c is a left turn.
long long area_signed_2x(const point &a, const point &b, const point &c) {
    return cross(b - a, c - a);
}
 
long double distance_to_line(const point &p, const point &a, const point &b) {
    assert(a != b);
    return abs(area_signed_2x(p, a, b)) / (a - b).dist();
}
 
long long manhattan_dist(const point &a, const point &b) {
    return (long long) abs(a.x - b.x) + abs(a.y - b.y);
}
 
long long infinity_norm_dist(const point &a, const point &b) {
    return max(abs(a.x - b.x), abs(a.y - b.y));
}
 
// Sort in increasing order of y, with ties broken in increasing order of x.
bool yx_compare(const point &a, const point &b) {
    return (b - a).top_half();
}
 
// Sort in increasing order of angle to the x-axis.
bool angle_compare(const point &a, const point &b) {
    if (a.top_half() ^ b.top_half())
        return a.top_half();
 
    return cross_sign(a, b) > 0;
}
 
using matrix_float = double;
 
struct float_column_vector {
    int rows;
    vector<matrix_float> values;
 
    float_column_vector(int _rows = 0) {
        init(_rows);
    }
 
    template<typename T>
    float_column_vector(const vector<T> &v) {
        init(v);
    }
 
    void init(int _rows) {
        rows = _rows;
        values.assign(rows, 0);
    }
 
    template<typename T>
    void init(const vector<T> &v) {
        rows = v.size();
        values.resize(rows);
 
        for (int i = 0; i < rows; i++)
            values[i] = v[i];
    }
 
    matrix_float& operator[](int index) { return values[index]; }
    const matrix_float& operator[](int index) const { return values[index]; }
};
 
// Warning: very inefficient for many small matrices of fixed size. For that, use float_matrix_fixed_size.cc instead.
struct float_matrix {
    int rows, cols;
    vector<vector<matrix_float>> values;
 
    float_matrix(int _rows = 0, int _cols = -1) {
        init(_rows, _cols);
    }
 
    template<typename T>
    float_matrix(const vector<vector<T>> &v) {
        init(v);
    }
 
    void init(int _rows, int _cols = -1) {
        rows = _rows;
        cols = _cols < 0 ? rows : _cols;
        values.assign(rows, vector<matrix_float>(cols, 0));
    }
 
    template<typename T>
    void init(const vector<vector<T>> &v) {
        rows = v.size();
        cols = v.empty() ? 0 : v[0].size();
        values.assign(rows, vector<matrix_float>(cols, 0));
 
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                values[i][j] = v[i][j];
    }
 
    vector<matrix_float>& operator[](int index) { return values[index]; }
    const vector<matrix_float>& operator[](int index) const { return values[index]; }
 
    bool is_square() const {
        return rows == cols;
    }
 
    void make_identity() {
        assert(is_square());
 
        for (int i = 0; i < rows; i++) {
            values[i].assign(cols, 0);
            values[i][i] = 1;
        }
    }
 
    float_matrix operator*(const float_matrix &other) const {
        assert(cols == other.rows);
        float_matrix product(rows, other.cols);
 
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                if (values[i][j] != 0)
                    for (int k = 0; k < other.cols; k++)
                        product[i][k] += values[i][j] * other[j][k];
 
        return product;
    }
 
    float_matrix& operator*=(const float_matrix &other) {
        assert(other.is_square() && cols == other.rows);
        return *this = *this * other;
    }
 
    float_column_vector operator*(const float_column_vector &column) const {
        assert(cols == column.rows);
        float_column_vector product(rows);
 
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                product[i] += values[i][j] * column[j];
 
        return product;
    }
 
    float_matrix power(long long p) const {
        assert(p >= 0);
        assert(is_square());
 
        float_matrix m = *this;
        float_matrix result(rows);
        result.make_identity();
 
        while (p > 0) {
            if (p & 1)
                result *= m;
 
            p >>= 1;
 
            if (p > 0)
                m *= m;
        }
 
        return result;
    }
 
    void print() const {
        cout << rows << ' ' << cols << '\n';
 
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                cout << values[i][j] << (j < cols - 1 ? ' ' : '\n');
    }
};
***********************************/

/*********************************
// https://codeforces.com/contest/1320/submission/72273525
namespace IO {
    const int BUFFER_SIZE = 1 << 15;
 
    char input_buffer[BUFFER_SIZE];
    int input_pos = 0, input_len = 0;
 
    char output_buffer[BUFFER_SIZE];
    int output_pos = 0;
 
    char number_buffer[100];
    uint8_t lookup[100];
 
    void _update_input_buffer() {
        input_len = fread(input_buffer, sizeof(char), BUFFER_SIZE, stdin);
        input_pos = 0;
 
        if (input_len == 0)
            input_buffer[0] = EOF;
    }
 
    inline char next_char(bool advance = true) {
        if (input_pos >= input_len)
            _update_input_buffer();
 
        return input_buffer[advance ? input_pos++ : input_pos];
    }
 
    template<typename T>
    inline void read_int(T &number) {
        bool negative = false;
        number = 0;
 
        while (!isdigit(next_char(false)))
            if (next_char() == '-')
                negative = true;
 
        do {
            number = 10 * number + (next_char() - '0');
        } while (isdigit(next_char(false)));
 
        if (negative)
            number = -number;
    }
 
    template<typename T, typename... Args>
    inline void read_int(T &number, Args &... args) {
        read_int(number);
        read_int(args...);
    }
 
    void _flush_output() {
        fwrite(output_buffer, sizeof(char), output_pos, stdout);
        output_pos = 0;
    }
 
    inline void write_char(char c) {
        if (output_pos == BUFFER_SIZE)
            _flush_output();
 
        output_buffer[output_pos++] = c;
    }
 
    template<typename T>
    inline void write_int(T number, char after = '\0') {
        if (number < 0) {
            write_char('-');
            number = -number;
        }
 
        int length = 0;
 
        while (number >= 10) {
            uint8_t lookup_value = lookup[number % 100];
            number /= 100;
            number_buffer[length++] = (lookup_value & 15) + '0';
            number_buffer[length++] = (lookup_value >> 4) + '0';
        }
 
        if (number != 0 || length == 0)
            write_char(number + '0');
 
        for (int i = length - 1; i >= 0; i--)
            write_char(number_buffer[i]);
 
        if (after)
            write_char(after);
    }
 
    void init() {
        // Make sure _flush_output() is called at the end of the program.
        bool exit_success = atexit(_flush_output) == 0;
        assert(exit_success);
 
        for (int i = 0; i < 100; i++)
            lookup[i] = (i / 10 << 4) + i % 10;
    }
}
 
template<typename T, bool maximum_mode = false>
struct RMQ {
    int n = 0, levels = 0;
    vector<T> values;
    vector<vector<int>> range_low;
 
    RMQ(const vector<T> &_values = {}) {
        if (!_values.empty())
            build(_values);
    }
 
    static int largest_bit(int x) {
        return 31 - __builtin_clz(x);
    }
 
    // Note: when `values[a] == values[b]`, returns b.
    int better_index(int a, int b) const {
        return (maximum_mode ? values[b] < values[a] : values[a] < values[b]) ? a : b;
    }
 
    void build(const vector<T> &_values) {
        values = _values;
        n = values.size();
        levels = largest_bit(n) + 1;
        range_low.resize(levels);
 
        for (int k = 0; k < levels; k++)
            range_low[k].resize(n - (1 << k) + 1);
 
        for (int i = 0; i < n; i++)
            range_low[0][i] = i;
 
        for (int k = 1; k < levels; k++)
            for (int i = 0; i <= n - (1 << k); i++)
                range_low[k][i] = better_index(range_low[k - 1][i], range_low[k - 1][i + (1 << (k - 1))]);
    }
 
    // Note: breaks ties by choosing the largest index.
    int query_index(int a, int b) const {
        assert(0 <= a && a < b && b <= n);
        int level = largest_bit(b - a);
        return better_index(range_low[level][a], range_low[level][b - (1 << level)]);
    }
 
    T query_value(int a, int b) const {
        return values[query_index(a, b)];
    }
};
 
struct LCA {
    int n = 0;
    vector<vector<int>> adj;
    vector<int> parent, depth, subtree_size;
    vector<int> euler, first_occurrence;
    vector<int> tour_start, tour_end, tour_list, postorder;
    vector<int> heavy_root;
    RMQ<int> rmq;
 
    LCA(int _n = 0) {
        init(_n);
    }
 
    // Warning: this does not call build().
    LCA(const vector<vector<int>> &_adj) {
        init(_adj);
    }
 
    void init(int _n) {
        n = _n;
        adj.assign(n, {});
        parent.resize(n);
        depth.resize(n);
        subtree_size.resize(n);
        first_occurrence.resize(n);
        tour_start.resize(n);
        tour_end.resize(n);
        tour_list.resize(n);
        postorder.resize(n);
        heavy_root.resize(n);
    }
 
    // Warning: this does not call build().
    void init(const vector<vector<int>> &_adj) {
        init(_adj.size());
        adj = _adj;
    }
 
    void add_edge(int a, int b) {
        adj[a].push_back(b);
        adj[b].push_back(a);
    }
 
    void dfs(int node, int par) {
        parent[node] = par;
        depth[node] = par < 0 ? 0 : depth[par] + 1;
        subtree_size[node] = 1;
 
        // Erase the edge to parent.
        if (par >= 0)
            adj[node].erase(find(adj[node].begin(), adj[node].end(), par));
 
        for (int &child : adj[node]) {
            dfs(child, node);
            subtree_size[node] += subtree_size[child];
        }
 
        // Heavy-light subtree reordering.
        sort(adj[node].begin(), adj[node].end(), [&](int a, int b) {
            return subtree_size[a] > subtree_size[b];
        });
    }
 
    int tour, post_tour;
 
    void tour_dfs(int node, bool heavy) {
        heavy_root[node] = heavy ? heavy_root[parent[node]] : node;
        first_occurrence[node] = euler.size();
        euler.push_back(node);
        tour_list[tour] = node;
        tour_start[node] = tour++;
        bool heavy_child = true;
 
        for (int child : adj[node]) {
            tour_dfs(child, heavy_child);
            euler.push_back(node);
            heavy_child = false;
        }
 
        tour_end[node] = tour;
        postorder[node] = post_tour++;
    }
 
    void build() {
        parent.assign(n, -1);
 
        for (int i = 0; i < n; i++)
            if (parent[i] < 0)
                dfs(i, -1);
 
        tour = post_tour = 0;
 
        for (int i = 0; i < n; i++)
            if (parent[i] < 0) {
                tour_dfs(i, false);
                // Add a -1 in between connected components to help us detect when nodes aren't connected.
                euler.push_back(-1);
            }
 
        assert((int) euler.size() == 2 * n);
        vector<int> euler_depths;
 
        for (int node : euler)
            euler_depths.push_back(node < 0 ? node : depth[node]);
 
        rmq.build(euler_depths);
    }
 
    pair<int, int> find_farthest(int node, int par, int path) const {
        pair<int, int> current = {path, node};
 
        for (int neighbor : adj[node])
            if (neighbor != par)
                current = max(current, find_farthest(neighbor, node, path + 1));
 
        return current;
    }
 
    // Warning: this must be called before build(), since build() erases half of the edges.
    pair<int, pair<int, int>> get_diameter() const {
        int u = find_farthest(0, -1, 0).second;
        pair<int, int> farthest = find_farthest(u, -1, 0);
        int v = farthest.second;
        return {farthest.first, {u, v}};
    }
 
    // Note: returns -1 if `a` and `b` aren't connected.
    int get_lca(int a, int b) const {
        a = first_occurrence[a];
        b = first_occurrence[b];
 
        if (a > b)
            swap(a, b);
 
        return euler[rmq.query_index(a, b + 1)];
    }
 
    bool is_ancestor(int a, int b) const {
        return tour_start[a] <= tour_start[b] && tour_start[b] < tour_end[a];
    }
 
    bool on_path(int x, int a, int b) const {
        return (is_ancestor(x, a) || is_ancestor(x, b)) && is_ancestor(get_lca(a, b), x);
    }
 
    int get_dist(int a, int b) const {
        return depth[a] + depth[b] - 2 * depth[get_lca(a, b)];
    }
 
    // Returns the child of `a` that is an ancestor of `b`. Assumes `a` is a strict ancestor of `b`.
    int child_ancestor(int a, int b) const {
        assert(a != b);
        assert(is_ancestor(a, b));
 
        // Note: this depends on RMQ breaking ties by latest index.
        int child = euler[rmq.query_index(first_occurrence[a], first_occurrence[b] + 1) + 1];
        assert(parent[child] == a);
        assert(is_ancestor(child, b));
        return child;
    }
 
    int get_kth_ancestor(int a, int k) const {
        while (a >= 0) {
            int root = heavy_root[a];
 
            if (depth[root] <= depth[a] - k)
                return tour_list[tour_start[a] - k];
 
            k -= depth[a] - depth[root] + 1;
            a = parent[root];
        }
 
        return a;
    }
 
    int get_kth_node_on_path(int a, int b, int k) const {
        int anc = get_lca(a, b);
        int first_half = depth[a] - depth[anc];
        int second_half = depth[b] - depth[anc];
        assert(0 <= k && k <= first_half + second_half);
 
        if (k < first_half)
            return get_kth_ancestor(a, k);
        else
            return get_kth_ancestor(b, first_half + second_half - k);
    }
 
    // Given a subset of k tree nodes, computes the minimal subtree that contains all the nodes (at most 2k - 1 nodes).
    // Returns a list of {node, parent} for every node in the subtree. Runs in O(k log k).
    vector<pair<int, int>> compress_tree(vector<int> nodes) const {
        if (nodes.empty())
            return {};
 
        auto &&compare_tour = [&](int a, int b) { return tour_start[a] < tour_start[b]; };
        sort(nodes.begin(), nodes.end(), compare_tour);
        int k = nodes.size();
 
        for (int i = 0; i < k - 1; i++)
            nodes.push_back(get_lca(nodes[i], nodes[i + 1]));
 
        sort(nodes.begin(), nodes.end(), compare_tour);
        nodes.resize(unique(nodes.begin(), nodes.end()) - nodes.begin());
        vector<pair<int, int>> result = {{nodes[0], -1}};
 
        for (int i = 1; i < (int) nodes.size(); i++)
            result.emplace_back(nodes[i], get_lca(nodes[i], nodes[i - 1]));
 
        return result;
    }
};
 
 
const int INF = 1e9 + 5;
 
struct state {
    int node;
    pair<int, int> dist;
 
    state() {}
 
    state(int _node, pair<int, int> _dist) : node(_node), dist(_dist) {}
 
    bool operator<(const state &other) const {
        return dist > other.dist;
    }
};
**********************************/

/***********************************
// https://codeforces.com/contest/1307/submission/72233574
template<typename T, bool maximum_mode = false>
struct block_RMQ {
    static const int BLOCK = 16;
 
    int n = 0;
    vector<T> values;
    vector<uint8_t> block_index, block_prefix, block_suffix;
    RMQ<T, maximum_mode> rmq;
 
    block_RMQ(const vector<T> &_values = {}) {
        if (!_values.empty())
            build(_values);
    }
 
    // Note: when `values[a] == values[b]` and `maximum_mode` is false, returns `b`.
    int better_index(int a, int b) const {
        return (maximum_mode ? values[b] < values[a] : values[a] < values[b]) ? a : b;
    }
 
    int get_block_start(int index) const {
        return index - index % BLOCK;
    }
 
    bool is_block_start(int index) const {
        return index % BLOCK == 0;
    }
 
    bool is_block_end(int index) const {
        return index == n - 1 || index % BLOCK == BLOCK - 1;
    }
 
    void build(const vector<T> &_values) {
        values = _values;
        n = values.size();
        block_prefix.assign(n + 1, 0);
        block_suffix.assign(n + 1, BLOCK - 1);
 
        // Manually fix the last block.
        for (int i = n - n % BLOCK; i <= n; i++)
            block_suffix[i] = (n - 1) % BLOCK;
 
        for (int i = 1; i <= n; i++) {
            int block_start = get_block_start(i);
            block_prefix[i] = (is_block_start(i) ? i : better_index(block_start + block_prefix[i - 1], i - 1)) - block_start;
        }
 
        for (int i = n - 1; i >= 0; i--) {
            int block_start = get_block_start(i);
            block_suffix[i] = (is_block_end(i) ? i : better_index(i, block_start + block_suffix[i + 1])) - block_start;
        }
 
        block_index.resize(n / BLOCK);
        vector<T> block_values(n / BLOCK);
 
        for (int i = 0; i < n / BLOCK; i++) {
            int block_start = BLOCK * i, best = block_start;
 
            for (int j = block_start + 1; j < block_start + BLOCK; j++)
                best = better_index(best, j);
 
            block_values[i] = values[best];
            block_index[i] = best - block_start;
        }
 
        rmq.build(block_values);
    }
 
    // Note: breaks ties by choosing the largest index.
    int query_index(int a, int b) const {
        assert(0 <= a && a < b && b <= n);
        int answer = a;
 
        // Check if we are strictly inside a block. Note we can't use (a - 1) / BLOCK because -1 / BLOCK rounds to 0.
        if ((a + BLOCK - 1) / BLOCK == b / BLOCK + 1) {
            for (int i = a + 1; i < b; i++)
                answer = better_index(answer, i);
 
            return answer;
        }
 
        int a_block_start = get_block_start(a);
 
        if (!is_block_start(a))
            answer = a_block_start + block_suffix[a];
 
        int a_block = (a + BLOCK - 1) / BLOCK, b_block = b / BLOCK;
 
        if (a_block < b_block) {
            int rmq_index = rmq.query_index(a_block, b_block);
            answer = better_index(answer, BLOCK * rmq_index + block_index[rmq_index]);
        }
 
        int b_block_start = get_block_start(b);
 
        if (!is_block_start(b))
            answer = better_index(answer, b_block_start + block_prefix[b]);
 
        return answer;
    }
 
    T query_value(int a, int b) const {
        return values[query_index(a, b)];
    }
};
**********************************

/***********************************
// https://codeforces.com/contest/1320/submission/72196279
struct segment {
    int count;
    hash_t hash_value;
    bool first = false, last = false;
 
    segment(int _count = 0, hash_t _hash_value = 0) : count(_count), hash_value(_hash_value) {}
 
    void join(segment other) {
        if (last && other.first) {
            hash_value = (hash_value - '1' + HASH_P) % HASH_P;
            hash_value = hash_value * INV_HASH_MULT % HASH_P;
            other.hash_value = (other.hash_value - (uint64_t) '1' * hash_pow[other.count - 1] % HASH_P + HASH_P) % HASH_P;
 
            count--;
            other.count--;
        }
 
        if (count == 0)
            first = other.first;
 
        if (other.count != 0)
            last = other.last;
 
        hash_value = (hash_value * hash_pow[other.count] + other.hash_value) % HASH_P;
        count += other.count;
 
        if (count == 0)
            first = last = false;
    }
 
    void join(const segment &a, const segment &b) {
        *this = a;
        join(b);
    }
};
 
int right_half[32];
 
struct basic_seg_tree {
    static const bool POWER_OF_TWO_MODE = true;
 
    int tree_n = 0;
    vector<segment> tree;
 
    basic_seg_tree(int n = -1) {
        if (n >= 0)
            init(n);
    }
 
    void init(int n) {
        if (POWER_OF_TWO_MODE) {
            tree_n = 1;
 
            while (tree_n < n)
                tree_n *= 2;
        } else {
            tree_n = n;
        }
 
        tree.assign(2 * tree_n, segment());
    }
 
    // Builds our tree from an array in O(n).
    void build(const vector<segment> &initial) {
        int n = initial.size();
        init(n);
        assert(n <= tree_n);
 
        for (int i = 0; i < n; i++)
            tree[tree_n + i] = initial[i];
 
        for (int position = tree_n - 1; position > 0; position--)
            tree[position].join(tree[2 * position], tree[2 * position + 1]);
    }
 
    segment query(int a, int b) const {
        assert(0 <= a && a <= b && b <= tree_n);
        segment answer;
        int r_size = 0;
 
        for (a += tree_n, b += tree_n; a < b; a /= 2, b /= 2) {
            if (a & 1)
                answer.join(tree[a++]);
 
            if (b & 1)
                right_half[r_size++] = --b;
        }
 
        for (int i = r_size - 1; i >= 0; i--)
            answer.join(tree[right_half[i]]);
 
        return answer;
    }
 
    segment query_single(int index) const {
        assert(0 <= index && index < tree_n);
        return tree[tree_n + index];
    }
 
    void join_up(int position) {
        while (position > 1) {
            position /= 2;
            tree[position].join(tree[2 * position], tree[2 * position + 1]);
        }
    }
 
    void update(int index, const segment &seg) {
        assert(0 <= index && index < tree_n);
        int position = tree_n + index;
        tree[position] = seg;
        join_up(position);
    }
};
***********************************/

/***********************************
// https://codeforces.com/contest/1320/submission/72176156
struct segment_change {
    long long to_add;
 
    segment_change(long long _to_add = 0) : to_add(_to_add) {}
 
    void reset() {
        to_add = 0;
    }
 
    bool has_change() const {
        return to_add != 0;
    }
 
    // Return the combined result of applying this segment change followed by `other`.
    segment_change combine(const segment_change &other) const {
        return segment_change(to_add + other.to_add);
    }
};
 
struct segment {
    long long maximum;
 
    segment(long long _maximum = -LL_INF) : maximum(_maximum) {}
 
    void apply(int, const segment_change &change) {
        maximum += change.to_add;
    }
 
    void join(const segment &other) {
        maximum = max(maximum, other.maximum);
    }
 
    void join(const segment &a, const segment &b) {
        *this = a;
        join(b);
    }
};
 
pair<int, int> right_half[32];
 
struct add_max_seg_tree {
    int tree_n = 0;
    vector<segment> tree;
    vector<segment_change> changes;
 
    add_max_seg_tree(int n = -1) {
        if (n >= 0)
            init(n);
    }
 
    void init(int n) {
        tree_n = 1;
 
        while (tree_n < n)
            tree_n *= 2;
 
        tree.assign(2 * tree_n, segment());
        changes.assign(tree_n, segment_change());
    }
 
    // Builds our tree from an array in O(n).
    void build(const vector<segment> &initial) {
        int n = initial.size();
        init(n);
        assert(n <= tree_n);
 
        for (int i = 0; i < n; i++)
            tree[tree_n + i] = initial[i];
 
        for (int position = tree_n - 1; position > 0; position--)
            tree[position].join(tree[2 * position], tree[2 * position + 1]);
    }
 
    void push_down(int position, int length) {
        if (!changes[position].has_change())
            return;
 
        if (2 * position < tree_n) {
            changes[2 * position] = changes[2 * position].combine(changes[position]);
            changes[2 * position + 1] = changes[2 * position + 1].combine(changes[position]);
        }
 
        tree[2 * position].apply(length / 2, changes[position]);
        tree[2 * position + 1].apply(length / 2, changes[position]);
        changes[position].reset();
    }
 
    // Calls push_down for all necessary nodes in order to query the range [a, b).
    void push_all(int a, int b) {
        assert(0 <= a && a < b && b <= tree_n);
        a += tree_n;
        b += tree_n - 1;
 
        for (int up = 31 - __builtin_clz(tree_n); up > 0; up--) {
            int x = a >> up, y = b >> up;
            push_down(x, 1 << up);
            if (x != y) push_down(y, 1 << up);
        }
    }
 
    void join_and_apply(int position, int length) {
        tree[position].join(tree[2 * position], tree[2 * position + 1]);
        tree[position].apply(length, changes[position]);
    }
 
    // Calls join for all necessary nodes after updating the range [a, b).
    void join_all(int a, int b) {
        assert(0 <= a && a < b && b <= tree_n);
        a += tree_n;
        b += tree_n - 1;
        int length = 1;
 
        while (a > 1) {
            a /= 2;
            b /= 2;
            length *= 2;
            join_and_apply(a, length);
            if (a != b) join_and_apply(b, length);
        }
    }
 
    template<typename T_range_op>
    void process_range(int a, int b, bool needs_join, T_range_op &&range_op) {
        if (a == b) return;
        push_all(a, b);
        int original_a = a, original_b = b;
        int length = 1, r_size = 0;
 
        for (a += tree_n, b += tree_n; a < b; a /= 2, b /= 2, length *= 2) {
            if (a & 1)
                range_op(a++, length);
 
            if (b & 1)
                right_half[r_size++] = {--b, length};
        }
 
        for (int i = r_size - 1; i >= 0; i--)
            range_op(right_half[i].first, right_half[i].second);
 
        if (needs_join)
            join_all(original_a, original_b);
    }
 
    segment query(int a, int b) {
        assert(0 <= a && a <= b && b <= tree_n);
        segment answer;
 
        process_range(a, b, false, [&](int position, int) {
            answer.join(tree[position]);
        });
 
        return answer;
    }
 
    void update(int a, int b, const segment_change &change) {
        assert(0 <= a && a <= b && b <= tree_n);
 
        process_range(a, b, true, [&](int position, int length) {
            tree[position].apply(length, change);
 
            if (position < tree_n)
                changes[position] = changes[position].combine(change);
        });
    }
 
    void set_value(int index, long long value) {
        assert(0 <= index && index < tree_n);
        long long current = query(index, index + 1).maximum;
        update(index, index + 1, segment_change(value - current));
    }
};
 
 
struct tool {
    int value, cost;
 
    bool operator<(const tool &other) const {
        return value < other.value;
    }
};
 
struct monster {
    int x, y, coins;
 
    bool operator<(const monster &other) const {
        return x < other.x;
    }
};
***********************************/

/***********************************
// https://codeforces.com/contest/1320/submission/72170560
struct BFS {
    struct edge {
        int node = -1, weight = -1;
 
        edge() {}
 
        edge(int _node, int _weight) : node(_node), weight(_weight) {}
    };
 
    int n;
    vector<vector<edge>> adj;
    vector<int> dist;
    vector<int> previous;
    vector<set<int>> previous_set;
 
    BFS(int _n = 0) {
        init(_n);
    }
 
    void init(int _n) {
        n = _n;
        adj.assign(n, {});
    }
 
    void add_directional_edge(int a, int b, int weight) {
        adj[a].emplace_back(b, weight);
    }
 
    void add_bidirectional_edge(int a, int b, int weight) {
        add_directional_edge(a, b, weight);
        add_directional_edge(b, a, weight);
    }
 
    void bfs_check(queue<int> &q, queue<int> &next_q, int node, int from, int new_dist, int add) {
        assert(0 <= add && add <= 1);
 
        if (new_dist < dist[node]) {
            dist[node] = new_dist;
            previous[node] = from;
            previous_set[node] = {from};
            (add == 0 ? q : next_q).push(node);
        } else if (new_dist == dist[node]) {
            previous_set[node].insert(from);
        }
    }
 
    void bfs(const vector<int> &source) {
        if (n == 0) return;
 
        // Two queues are needed for 0-1 BFS.
        queue<int> q, next_q;
        dist.assign(n, INF);
        previous.assign(n, -1);
        previous_set.assign(n, {});
 
        for (int src : source)
            bfs_check(q, next_q, src, -1, 0, 0);
 
        int level = 0;
 
        while (!q.empty() || !next_q.empty()) {
            while (!q.empty()) {
                int top = q.front(); q.pop();
 
                if (level > dist[top])
                    continue;
 
                for (edge &e : adj[top])
                    bfs_check(q, next_q, e.node, top, dist[top] + e.weight, e.weight);
            }
 
            swap(q, next_q);
            level++;
        }
    }
};
***********************************/

/***********************************
// https://codeforces.com/contest/1311/submission/71933816
template<typename T>
struct fenwick_tree {
    int tree_n = 0;
    T tree_sum = 0;
    vector<T> tree;
 
    fenwick_tree(int n = -1) {
        if (n >= 0)
            init(n);
    }
 
    void init(int n) {
        tree_n = n;
        tree_sum = 0;
        tree.assign(tree_n + 1, 0);
    }
 
    // O(n) initialization of the Fenwick tree.
    template<typename T_array>
    void build(const T_array &initial) {
        assert((int) initial.size() == tree_n);
        tree_sum = 0;
 
        for (int i = 1; i <= tree_n; i++) {
            tree[i] = initial[i - 1];
            tree_sum += initial[i - 1];
 
            for (int k = (i & -i) >> 1; k > 0; k >>= 1)
                tree[i] += tree[i - k];
        }
    }
 
    // index is in [0, tree_n).
    void update(int index, const T &change) {
        assert(0 <= index && index < tree_n);
        tree_sum += change;
 
        for (int i = index + 1; i <= tree_n; i += i & -i)
            tree[i] += change;
    }
 
    // Returns the sum of the range [0, count).
    T query(int count) const {
        assert(count <= tree_n);
        T sum = 0;
 
        for (int i = count; i > 0; i -= i & -i)
            sum += tree[i];
 
        return sum;
    }
 
    // Returns the sum of the range [start, tree_n).
    T query_suffix(int start) const {
        return tree_sum - query(start);
    }
 
    // Returns the sum of the range [a, b).
    T query(int a, int b) const {
        return query(b) - query(a);
    }
 
    // Returns the element at index a in O(1) amortized across every index. Equivalent to query(a, a + 1).
    T get(int a) const {
        assert(0 <= a && a < tree_n);
        int above = a + 1;
        T sum = tree[above];
        above -= above & -above;
 
        while (a != above) {
            sum -= tree[a];
            a -= a & -a;
        }
 
        return sum;
    }
 
    bool set(int index, T value) {
        assert(0 <= index && index < tree_n);
        T current = get(index);
 
        if (current == value)
            return false;
 
        update(index, value - current);
        return true;
    }
 
    // Returns the largest i in [0, tree_n] such that query(i) <= sum. Returns -1 if no such i exists (sum < 0).
    // Can be used as an ordered set on indices in [0, tree_n) by using the tree as a 0/1 array:
    // set(index, 1) is equivalent to insert(index).
    // set(index, 0) is equivalent to erase(index).
    // get(index) provides whether index is present or not.
    // query(index) provides the count of elements < index.
    // find_last_prefix(k) finds the k-th smallest element (0-indexed).
    int find_last_prefix(T sum) const {
        if (sum < 0)
            return -1;
 
        int prefix = 0;
 
        for (int k = 31 - __builtin_clz(tree_n); k >= 0; k--)
            if (prefix + (1 << k) <= tree_n && tree[prefix + (1 << k)] <= sum) {
                prefix += 1 << k;
                sum -= tree[prefix];
            }
 
        return prefix;
    }
};
***********************************/

/***********************************
// https://codeforces.com/contest/1314/submission/71736097
template<typename T_string = string>
struct suffix_array {
    int n = 0;
    T_string str;
    vector<int> suffix;
    vector<int> rank;
    vector<int> lcp;
    RMQ<int> rmq;
 
    suffix_array() {}
 
    suffix_array(const T_string &_str, bool build_rmq = true) {
        build(_str, build_rmq);
    }
 
    void build(const T_string &_str, bool build_rmq = true) {
        str = _str;
        n = str.size();
        suffix.resize(n);
 
        for (int i = 0; i < n; i++)
            suffix[i] = i;
 
        bool large_alphabet = false;
 
        for (int i = 0; i < n; i++)
            if (str[i] < 0 || str[i] >= 128)
                large_alphabet = true;
 
        // Sort each suffix by the first character.
        if (large_alphabet) {
            sort(suffix.begin(), suffix.end(), [&](int a, int b) {
                return str[a] < str[b];
            });
        } else {
            vector<int> freq(128, 0);
 
            for (int i = 0; i < n; i++)
                freq[str[i]]++;
 
            for (int c = 1; c < 128; c++)
                freq[c] += freq[c - 1];
 
            for (int i = 0; i < n; i++)
                suffix[--freq[str[i]]] = i;
        }
 
        // Compute the rank of each suffix. Tied suffixes share the same rank.
        rank.resize(n);
        rank[suffix[0]] = 0;
 
        for (int i = 1; i < n; i++)
            rank[suffix[i]] = str[suffix[i]] == str[suffix[i - 1]] ? rank[suffix[i - 1]] : i;
 
        vector<int> next_index(n);
        vector<int> values(n);
        bool done = false;
 
        for (int len = 1; len < n && !done; len *= 2) {
            // next_index[i] = the next index to use for a suffix of rank i. We insert them in order of the rank of the
            // suffix that comes len characters after the current suffix.
            for (int i = 0; i < n; i++)
                next_index[i] = i;
 
            // Compute the suffix array for 2 * len. Suffixes of length <= len are prioritized first.
            for (int i = n - len; i < n; i++)
                values[next_index[rank[i]]++] = i;
 
            for (int i = 0; i < n; i++) {
                int prev = suffix[i] - len;
 
                if (prev >= 0)
                    values[next_index[rank[prev]]++] = prev;
            }
 
            swap(suffix, values);
 
            // Compute the rank array for 2 * len.
            values[suffix[0]] = 0;
            done = true;
 
            for (int i = 1; i < n; i++) {
                int s = suffix[i], prev = suffix[i - 1];
 
                if (s + len < n && prev + len < n && rank[s] == rank[prev] && rank[s + len] == rank[prev + len]) {
                    values[s] = values[prev];
                    done = false;
                } else {
                    values[s] = i;
                }
            }
 
            swap(rank, values);
        }
 
        compute_lcp();
 
        if (build_rmq)
            rmq.build(lcp);
    }
 
    void compute_lcp() {
        lcp.assign(n, 0);
        int match = 0;
 
        for (int i = 0; i < n; i++) {
            if (rank[i] == 0)
                continue;
 
            int a = suffix[rank[i]] + match;
            int b = suffix[rank[i] - 1] + match;
 
            while (a < n && b < n && str[a++] == str[b++])
                match++;
 
            // lcp[r] = the longest common prefix length of the suffixes starting at suffix[r] and at suffix[r - 1].
            lcp[rank[i]] = match;
            match = max(match - 1, 0);
        }
    }
 
    int get_lcp_from_ranks(int a, int b) const {
        if (a == b)
            return n - suffix[a];
 
        if (a > b)
            swap(a, b);
 
        return rmq.query_value(a + 1, b + 1);
    }
 
    int get_lcp(int a, int b) const {
        if (a >= n || b >= n)
            return 0;
 
        if (a == b)
            return n - a;
 
        return get_lcp_from_ranks(rank[a], rank[b]);
    }
 
    // Compares the substrings starting at `a` and `b` up to `length`.
    int compare(int a, int b, int length = -1) const {
        if (length < 0)
            length = n;
 
        if (a == b)
            return 0;
 
        int common = get_lcp(a, b);
 
        if (common >= length)
            return 0;
 
        if (a + common >= n || b + common >= n)
            return a + common >= n ? -1 : 1;
 
        return str[a + common] < str[b + common] ? -1 : (str[a + common] == str[b + common] ? 0 : 1);
    }
};
***********************************/

/***********************************
// 
struct edge {
    int uv; //int id;
    edge (int _uv = 0, __attribute__((unused))monostate _ = ms) : uv(_uv) {}
    int operator()(int u) const { assert(uv); return uv ^ u; }
    monostate& wt() const { return ms; }
    struct path { int len;
        path operator+(const path& p) const { return {len+p.len}; }
    }; explicit operator path() { return {1}; }
};
template<typename W> struct wedge : edge {
    mutable W w;
    wedge (int _uv = 0, W _w = {}) : edge(_uv), w(_w) {}
    W& wt() const { return w; }
    struct path { int len; W wt;
        path operator+(const path& p) { return {len+p.len, wt+p.wt}; }
    }; explicit operator path() { return {1, w}; }
};
 
enum INPUT_FORMAT { EDGE_LIST, PARENT_LIST };
template<typename E> struct tree {
    int V, root;
    vector<vector<E>> nbrs, children;
 
    vi par, depth, subt_sz;
    vi preorder, reverse_preorder;
 
    tree() : V(0), root(-1) {}
    tree(int _V, int _root) : V(_V), root(_root), nbrs(V) {}
 
    const E& up_edge(int u) const {
        assert(u != root);
        return nbrs[u].front();
    }
 
    void add_edge(int u, int v, E e = {}) {
        assert(0 <= u && u < V && 0 <= v && v < V);
        e.uv = u ^ v;
        nbrs[u].pb(e);
        nbrs[v].pb(e);
    }
 
    template<INPUT_FORMAT FMT = EDGE_LIST, bool FIRST_INDEX = 1>
    friend void re(tree& t) {
        assert(t.V > 0);
        for (int i = 0; i < t.V - 1; i++) {
            int u, v;
            IO::read_int(u), u -= FIRST_INDEX;
            if (FMT == PARENT_LIST) v = i+1;
            else IO::read_int(v), v -= FIRST_INDEX;
            E e{}; IO::read_int(e.wt()); // e.id = i
            t.add_edge(u, v, e);
        }
        t.init();
    }
 
    void init() {
        children.resz(V), par.resz(V), depth.resz(V), subt_sz.resz(V);
        par[root] = -1, depth[root] = 0;
 
        traverse(root);
        for (int u = 0; u < V; u++) {
            sort_by(nbrs[u], subt_sz[a(u)] > subt_sz[b(u)]);
            children[u].clear();
            copy(nbrs[u].begin() + (u != root), nbrs[u].end(), back_inserter(children[u]));
        }
 
        preorder.clear(), preorder.reserve(V), build_preorder(root);
        reverse_preorder = preorder, reverse(all(reverse_preorder));
    }
    void reroot(int _root) { root = _root; init(); }
 
    void traverse(int u) {
        subt_sz[u] = 1;
        for (E e : nbrs[u]) if (int v = e(u); v != par[u]) {
            par[v] = u;
            depth[v] = depth[u] + 1;
            traverse(v);
            subt_sz[u] += subt_sz[v];
        }
    }
 
    void build_preorder(int u) {
        preorder.pb(u);
        for (E e : children[u]) build_preorder(e(u));
    }
 
    friend void pr(const tree& t) {
        pr("{V=", t.V, " root=", t.root, " |");
        for (int u = 0; u < t.V; u++) {
            pr(" ", u, "--{");
            for (E e : t.children[u])
                pr("(ch=", e(u), " wt=", e.wt(), ")");
            pr("}");
        }
        pr("}");
    }
};
// }}}
// heavy_path_decomposition {{{
struct index_t {
    int i; explicit operator int() { return i; }
    friend bool operator  < (const index_t& a, const index_t& b) { return a.i  < b.i; }
    friend bool operator <= (const index_t& a, const index_t& b) { return a.i <= b.i; }
    friend bool operator  > (const index_t& a, const index_t& b) { return a.i  > b.i; }
    index_t operator + (int b) { return {i+b}; }
    index_t operator - (int b) { return {i-b}; }
    int operator - (index_t b) { return i-b.i; }
    friend ostream& operator << (ostream& o, index_t a) { o << a.i; return o; }
};
using range_t = pair<index_t, index_t>;
using ranges = vector<range_t>;
template<typename E> struct heavy_path_decomposition {
    const tree<E>& t;
    // Any node identifier represented as an index_t indexes into the decomposition's relabeling.
    // Any node identifier represented as a plain int indexes into the original tree's labeling.
    struct heavy_path { index_t index; int htop; };
    vector<heavy_path> hld;
 
    heavy_path_decomposition() {}
    heavy_path_decomposition(const tree<E>& _t) : t(_t), hld(t.V) {
        for (int i = 0; i < t.V; i++) {
            int u = t.preorder[i];
            hld[u] = {
                index_t{i},
                i > 0 && t.preorder[i-1] == t.par[u] ? hld[t.par[u]].htop : u
            };
        }
    }
 
    index_t index(int v) const { return hld[v].index; }
    int at_index(index_t i) const { return t.preorder[int(i)]; }
    int htop(int v) const { return hld[v].htop; }
 
    int lca(int u, int v) const {
        while (htop(u) != htop(v)) {
            int& jump = index(htop(u)) > index(htop(v)) ? u : v;
            jump = t.par[htop(jump)];
        }
        return t.depth[u] < t.depth[v] ? u : v;
    }
 
    int dist(int u, int v) const {
        return t.depth[u] + t.depth[v] - 2 * t.depth[lca(u, v)];
    }
 
    bool uv_path_has_w(int u, int v, int w) const {
        return w != -1 && dist(u, v) == (dist(u, w) + dist(w, v));
    }
 
    bool is_ancestor(int anc, int desc) const {
        return index(anc) <= index(desc) && index(desc) < index(anc) + t.subt_sz[anc];
    }
 
    E first_step(int u, int v) const {
        assert(u != v);
        if (!is_ancestor(u, v)) return t.up_edge(u);
        return *upper_bound(all(t.children[u]), v,
            [&](int v, E c) { return index(v) < index(c(u)) + t.subt_sz[c(u)]; });
    }
 
    int par(int v) const { return t.par[v]; }
    int depth(int v) const { return t.depth[v]; }
 
    int kth_ancestor(int u, int k) const {
        assert(0 <= k && k <= depth(u));
        while (true) {
            if (k <= depth(u) - depth(htop(u)))
                return at_index(index(u) - k);
            k -= depth(u) - depth(htop(u)) + 1;
            u = par(htop(u));
        }
    }
 
    // Returns the kth node on the simple path from u to v
    int kth_step(int u, int v, int k) const {
        int w = this->lca(u, v), d = this->dist(u, v);
        assert(d >= k);
        return k <= depth(u) - depth(w) ? kth_ancestor(u, k) : kth_ancestor(v, d - k);
    }
 
    mutable int path_lca;
    mutable ranges path_up, path_down;
    void decompose_path(int u, int v, bool include_lca) const {
        path_up.clear(), path_down.clear();
        while (htop(u) != htop(v)) {
            int& jump = index(htop(u)) > index(htop(v)) ? u : v;
            (jump == u ? path_up : path_down).eb(index(htop(jump)), index(jump) + 1);
            jump = t.par[htop(jump)];
        }
        path_lca = t.depth[u] < t.depth[v] ? u : v;
        if (u != v || include_lca) {
            (u != path_lca ? path_up : path_down).eb(
                    index(path_lca) + !include_lca, index(path_lca^u^v) + 1);
        }
        reverse(all(path_down));
    }
 
    template<typename FOR, typename FORd>
    void for_each(int u, int v, bool include_lca, const FOR& f, const FORd& fd) const {
        decompose_path(u, v, include_lca);
        for (range_t r : path_up)    f(r.f, r.s);
        for (range_t r : path_down) fd(r.f, r.s);
    }
    template<typename FOR>
    void for_each_commutative(int u, int v, bool include_lca, const FOR& f) const {
        for_each(u, v, include_lca, f, f);
    }
 
    template<typename T, typename OP, typename FOLDL, typename FOLDR>
    T accumulate(int u, int v, bool include_lca, T iv,
            const OP& lplus, const FOLDL& fl, const FOLDR& fr) const {
        decompose_path(u, v, include_lca);
        for (range_t r : path_up)   iv = lplus(iv, fr(r.f, r.s));
        for (range_t r : path_down) iv = lplus(iv, fl(r.f, r.s));
        return iv;
    }
    template<typename T, typename OP, typename FOLD>
    T accumulate_commutative(int u, int v, bool include_lca, T iv,
            const OP& lplus, const FOLD& f) const {
        return accumulate(u, v, include_lca, iv, lplus, f, f);
    }
};
namespace __input {
    template<class T1, class T2> void re(pair<T1,T2>& p);
    template<class T> void re(vector<T>& a);
    template<class T, size_t SZ> void re(array<T,SZ>& a);
 
    template<class T> void re(T& x) { cin >> x; }
    void re(double& x) { string t; re(t); x = stod(t); }
    template<class Arg, class... Args> void re(Arg& first, Args&... rest) {
        re(first); re(rest...);
    }
 
    template<class T1, class T2> void re(pair<T1,T2>& p) { re(p.f,p.s); }
    template<class T> void re(vector<T>& a) { F0R(i,sz(a)) re(a[i]); }
    template<class T, size_t SZ> void re(array<T,SZ>& a) { F0R(i,SZ) re(a[i]); }
}
using namespace __input;
 
namespace __output {
    template<class T1, class T2> void pr(const pair<T1,T2>& x);
    template<class T, size_t SZ> void pr(const array<T,SZ>& x);
    template<class T> void pr(const vector<T>& x);
    template<class T> void pr(const deque<T>& x);
    template<class T> void pr(const set<T>& x);
    template<class T1, class T2> void pr(const map<T1,T2>& x);
 
    template<class T> void pr(const T& x) { cout << x; }
    template<class Arg, class... Args> void pr(const Arg& first, const Args&... rest) {
        pr(first); pr(rest...);
    }
 
    template<class T1, class T2> void pr(const pair<T1,T2>& x) {
        pr("{",x.f,", ",x.s,"}");
    }
    template<class T, bool pretty = true> void prContain(const T& x) {
        if (pretty) pr("{");
        bool fst = 1; for (const auto& a: x) pr(!fst?pretty?", ":" ":"",a), fst = 0;
        if (pretty) pr("}");
    }
    template<class T> void pc(const T& x) { prContain<T, false>(x); pr("\n"); }
    template<class T, size_t SZ> void pr(const array<T,SZ>& x) { prContain(x); }
    template<class T> void pr(const vector<T>& x) { prContain(x); }
    template<class T> void pr(const deque<T>& x) { prContain(x); }
    template<class T> void pr(const set<T>& x) { prContain(x); }
    template<class T1, class T2> void pr(const map<T1,T2>& x) { prContain(x); }
 
    void ps() { pr("\n"); }
    template<class Arg> void ps(const Arg& first) {
        pr(first); ps();
    }
    template<class Arg, class... Args> void ps(const Arg& first, const Args&... rest) {
        pr(first," "); ps(rest...);
    }
}
using namespace __output;
 
#define TRACE(x) x
#define __pn(x) pr(#x, " = ")
#define pd(...) __pn((__VA_ARGS__)), ps(__VA_ARGS__), cout << flush
 
namespace __algorithm {
    template<typename T> void dedup(vector<T>& v) {
        sort(all(v)); v.erase(unique(all(v)), v.end());
    }
    template<typename T> typename vector<T>::iterator find(vector<T>& v, const T& x) {
        auto it = lower_bound(all(v), x); return it != v.end() && *it == x ? it : v.end();
    }
    template<typename T> size_t index(vector<T>& v, const T& x) {
        auto it = find(v, x); assert(it != v.end() && *it == x); return it - v.begin();
    }
    template<typename C, typename T, typename OP> vector<T> prefixes(const C& v, T id, OP op) {
        vector<T> r(sz(v)+1, id); F0R (i, sz(v)) r[i+1] = op(r[i], v[i]); return r;
    }
    template<typename C, typename T, typename OP> vector<T> suffixes(const C& v, T id, OP op) {
        vector<T> r(sz(v)+1, id); F0Rd (i, sz(v)) r[i] = op(v[i], r[i+1]); return r;
    }
}
using namespace __algorithm;
 
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"
struct monostate {
    friend istream& operator>>(istream& is, const monostate& ms) { return is; }
    friend ostream& operator<<(ostream& os, const monostate& ms) { return os; }
    friend monostate operator+(const monostate& a, const monostate& b) { return a; }
} ms;
#pragma GCC diagnostic pop

***********************************/

/***********************************
// 

***********************************/

/***********************************
// 

***********************************/
