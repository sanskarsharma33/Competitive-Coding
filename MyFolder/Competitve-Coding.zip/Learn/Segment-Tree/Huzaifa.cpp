// link : https://codeforces.com/contest/1326/submission/73793822

struct data{
	int a,e;
	bool lz;
};
class segment_tree{
	private:
	vector<data> tree;
	function<data(data,data)> merge;
	public:
	segment_tree(auto fnc,int size){
		merge=fnc;
		tree.resize(4*size);
	}
	segment_tree(auto fnc){
		merge=fnc;
		tree.resize(4*MAX);
	}
	void build(int node,int l,int r){
		if(l>r)
			return;
		if(l==r){
			tree[node].a=0;
			tree[node].e=0;
			tree[node].lz=false;
			return;
		}
		int m=(l+r)/2;
		build(2*node,l,m);
		build(2*node+1,m+1,r);
		tree[node].a=0;
		tree[node].e=0;
		tree[node].lz=false;
		return;
	}
	void calclazy(int node,int l,int r,int x,int y){
		if(!tree[node].lz)
			return;
		tree[node].lz=false;
		tree[node].a+=tree[node].e;
		if(l!=r){
			tree[2*node].lz=true;
			tree[2*node+1].lz = true; 
			tree[2*node].e+=tree[node].e;
			tree[2*node+1].e+=tree[node].e; 
		}
		tree[node].e=0;
		return;	
	}
	void updateRange(int node,int l,int r,int x,int y,int z){
		calclazy(node,l,r,x,y);
		if(l>r || x>r || y<l)
			return ;
		if(l>=x && r<=y){
			tree[node].e+=z;
			tree[node].lz=true;
			calclazy(node,l,r,x,y);
			return;
		}
		int m=(l+r)/2;
		updateRange(2*node,l,m,x,y,z);
		updateRange(2*node +1,m+1,r,x,y,z);
		tree[node]=merge(tree[2*node],tree[2*node+1]);
		return;
	}
	data query(int node,int l,int r,int x, int y){
		calclazy(node,l,r,x,y);
		if(l>r || x>r || y<l){
			data grbg={0,0,0};
			return grbg;
		}
		if(l>=x && r<=y)
			return tree[node];
		int m=(l+r)/2;
		if(m>=y)
			return query(2*node,l,m,x,y);
		else if(m<x)
			return query(2*node+1,m+1,r,x,y); 
		data t1=query(2*node,l,m,x,y);
		data t2=query(2*node+1,m+1,r,x,y);
		data tr;
		tr=merge(t1,t2);
		return tr;
	}
};