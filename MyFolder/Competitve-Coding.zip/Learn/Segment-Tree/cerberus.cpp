// link : https://codeforces.com/contest/1326/submission/73707034

const int N = 3e5 + 10;
 
int tree[4 * N], sum[4 * N];
 
void update(int i, int l, int r, int p, int x);







void update(int i, int l, int r, int p, int x) {
	if (p < l or p > r) {
		return;
	} else if (l == r) {
		sum[i] += x;
		tree[i] = max(0, sum[i]);
	} else {
		int mid = (l + r) / 2, lc = 2 * i, rc = lc + 1;
		update(lc, l, mid, p, x);
		update(rc, mid + 1, r, p, x);
		sum[i] = sum[lc] + sum[rc];
		tree[i] = max(tree[rc], sum[rc] + tree[lc]);
	}
}