//link : https://codeforces.com/contest/1326/submission/73698006

struct node{
	int sum, sfx;
	node operator+(const node &n)const{
		return (node){sum + n.sum, max(n.sfx, n.sum + sfx)};
	}
};
 
	node sex(int x){
		return (node){x, max(x, 0)};
	}
struct seg{
	node tree[MAXT];
	int lim;
	void init(int n){
		for(lim = 1; lim <= n; lim <<= 1);
	}
	void upd(int x, int v){
		x += lim;
		tree[x] = sex(v);
		for(int i=x/2; i>=1; i>>=1){
			tree[i] = tree[2*i] + tree[2*i+1];
		}
	}
}seg;
 
int n;
int rev[MAXN], p[MAXN];