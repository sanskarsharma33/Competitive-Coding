#include<bits/stdc++.h>
using namespace std;

class TreeNode
{
    public:
        TreeNode* next[2];
        TreeNode(){next[0]=next[1]=NULL;}
};
TreeNode* buildTree(vector<int>& nums)
{
    TreeNode* root=new TreeNode(),*cur;
    size_t n=nums.size();
    
    for(size_t i=0;i<n;i++)
    {
        int num=nums[i];
        cur=root;
        
        for(int j = 31; j >= 0; j--)
        {
            bool index=(num>>j)&1;
            if(cur->next[index]==NULL)
                cur->next[index]=new TreeNode();
            cur=cur->next[index];
        }
    }
    return root;
}
    
int helper(TreeNode* cur,int num)
{
    int res=0;
    for(int i=31;i>=0;i--)
    {    
        bool index=(num>>i)&1?0:1;
        
        if(cur->next[index])
        {
            res<<=1;
            res|=1;
            cur=cur->next[index];
        }
        else
        {
            res<<=1;
            res|=0;
            cur=cur->next[index?0:1];
        }
    }
    return res;
}