//__builtin_clz(num) --> clz = count leading zero’s
//__builtin_ctz(num) --> ctz = count trailing zeros
//inline int LeftOne(int x){return (__builtin_clz(INT_MAX) - __builtin_clz(x)+1);}
// inline int RightOne(int x){return (__builtin_ctz(x)+1);}

int num_to_bits[16]={0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4};
ui popcount(ui num){int nibble;ui ans=0;do{nibble=num&0xf;ans+=num_to_bits[nibble];num>>=4;}while(num);return ans;}
inline void set(int &x,int pos){x|=(1LL<<pos);}
inline void reset(int &x,int pos){x&=~(1LL<<pos);}
inline bool atpos(int x,int pos){return ((x&(1LL<<pos))!=0);}