string ans;
const int mxBU = 36;
vector<char> base_util(mxBU);

void convert_x_to_ten(int x)
{
    // x -> 10(decimal)
    ll val=0;
    int n=ans.length();
    for(int i : range(n))
        val=x*val+ans[i]-'0';
    ans=to_string(val);
}

void convert_ten_to_y(int y)
{
    // 10(decimal) -> y
    ll val=stoll(ans);
    string t="";
    vector<char> mp(36,0);

    while(val)
    {
        t+=base_util[val%y];
        val/=y;
    }
    reverse(all(t));
    ans=t;
}

void convert_base(int x,int y)
{
    for(int i : range(10))
        base_util[i]=i+'0';
    for(int i : range(26))
        base_util[i+10]=i+'a';
    // x -> y
    convert_x_to_ten(x);
    convert_ten_to_y(y);
}