const int MAXN=1e6+1729;
vi __SIEVE__(MAXN,-1);
void build(int limit=MAXN-1)
{
    __SIEVE__[0]=__SIEVE__[1]=0;
    loop(i,2,limit)
    {
        if(__SIEVE__[i]==-1)
        {
            for(int j=2*i;j<=limit;j+=i)
            {
                if(__SIEVE__[j]==-1)
                    __SIEVE__[j]=i;
            }
        }
    }
}

bool is_sprime(int num){return __SIEVE__[num]==-1;}

void sfact(int num,map<int, int> &ans)
{
    int n=num;
    if(num<=1){ans[num]++;return;}
    while(1)
    {
        if(__SIEVE__[n]==-1)
        {
            ans[n]++;
            break;
        }
        ans[__SIEVE__[n]]++;
        n/=__SIEVE__[n];
    }
}